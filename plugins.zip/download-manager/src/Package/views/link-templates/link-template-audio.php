<!-- WPDM Link Template: With Audio Preview -->
<div class="w3eden">
<div class="media thumbnail">
    <div class="mr-3">
    [play_button]
    </div>
    <div class="media-body">
    <h3 class="media-heading p-0 m-0 mb-1 mt-2">[page_link]</h3>
    <div class="text-small text-muted">
    <i class="fas fa-hdd"></i> [file_size] <i class="far fa-arrow-alt-circle-down ml-3"></i> [download_count] [txt=downloads]
    </div>

    </div>
</div>
</div>
