<?php
/**
 * Base: wpdmpro
 * Developer: shahjada
 * Team: W3 Eden
 * Date: 2019-08-05 16:16
 */

if(!defined("ABSPATH")) die();
?>
ok
